require 'test_helper'

class UsersControllerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
